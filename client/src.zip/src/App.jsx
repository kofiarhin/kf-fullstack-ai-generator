import Home from "./Pages/Home/Home";
const app = () => {
  return (
    <div className="container">
      <Home />
    </div>
  );
};

export default app;
