import { render } from "preact";
import "./main.styles.scss";
import App from "./App.jsx";

render(<App />, document.getElementById("app"));
