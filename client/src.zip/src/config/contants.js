const BASE_URL = import.meta.env.VITE_BASE_URL;
const DEV_ENV = import.meta.env.VITE_DEV_ENV;

export { BASE_URL, DEV_ENV };
